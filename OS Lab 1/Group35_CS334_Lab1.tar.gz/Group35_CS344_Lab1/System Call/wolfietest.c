#include "types.h"
#include "user.h"

int main(int argc, char *argv[]){
	printf(1, "I am a wolf. wooo.....\n\n");
	char wolf[500];
	wolfie(wolf, 500);
	printf(1, wolf);
	exit();
}